### כללי

* [ברווזגומי](https://barvazgumi.podbean.com) (פודקאסט)
* [מדברים סייבר](https://podcastim.org.il/מדברים-סייבר) (פודקאסט)
* [מפתחים חסרי תרבות](http://notarbut.co) (פודקאסט)
* [עושים תוכנה](https://www.osimhistoria.com/software) (פודקאסט)
* [פרונטאנד לנד](https://podcastim.org.il/פרונטאנד-לנד) (פודקאסט)
* [צרות בהייטק](https://hitechproblems.podbean.com) (פודקאסט)
* [רברס עם פלטפורמה](https://www.reversim.com) (פודקאסט)
