### Index

* [0 - Meta-Lists](#0---meta-lists)
* [C](#c)


### 0 - Meta-Lists

* [Books - Telugu](https://sites.google.com/nptel.iitm.ac.in/translated-ebook/telugu)


### <a id="c"></a>C

* [Introduction to C \| Telugu](https://www.computerintelugu.com/2012/11/cmenu.html) - Sivanaadh Baazi Karampudi

