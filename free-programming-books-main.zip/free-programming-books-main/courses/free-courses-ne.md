### Index

* [JavaScript](#javascript)
    * [Node.js](#nodejs)
    * [React](#react)
* [Flutter](#flutter)
* [SQL](#sql)
* [C](#c)
* [WordPress](#wordpress)


### JavaScript

* [JavaScript](https://www.youtube.com/playlist?list=PLckS_N3kOwFH-GCqCd6i-vPo-Z75DcOnc) - EverydayKarma 🇳🇵


#### Node.js

* [Node js](https://www.youtube.com/playlist?list=PLckS_N3kOwFEJnIy0PG0zU6XjUOBGkW9x) - EverydayKarma 🇳🇵


#### React

* [React.js](https://www.youtube.com/playlist?list=PLckS_N3kOwFHhFEmcRs8jvX7xFaRFI4H1) - EverydayKarma 🇳🇵


#### Flutter

* [Flutter Complete Tutorial In Nepali](https://www.youtube.com/watch?v=N0cDdu32IaA&list=PL2OJkQtHPRicxyldFGNJRRG4WwNe0Kjqe&index=1) - Technology Channel


#### SQL

* [SQL Full Course In Nepali](https://www.youtube.com/watch?v=Lt52pYaoSR8&list=PL2OJkQtHPRicxyldFGNJRRG4WwNe0Kjqe&index=2) - Technology Channel


#### C

* [C Programming Full Course In Nepali](https://www.youtube.com/watch?v=7WH8C48UNDU&list=PL2OJkQtHPRicxyldFGNJRRG4WwNe0Kjqe&index=3) - Technology Channel


#### WordPress

* [WordPress Complete Tutorial In Nepali](https://www.youtube.com/playlist?list=PL2OJkQtHPRie2xyBApANdVp_LUz4v7xIG) - Technology Channel

