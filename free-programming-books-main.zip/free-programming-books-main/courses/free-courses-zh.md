### Index

* [0 - MOOC](#0---mooc)
* [Linux](#linux)


### 0 - MOOC

* [freeCodeCamp](https://chinese.freecodecamp.org)


### Linux

* [Linux 核心設計](https://youtube.com/playlist?list=PL6S9AqLQkFpongEA75M15_BlQBC9rTdd8) - jserv
